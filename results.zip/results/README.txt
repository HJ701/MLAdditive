This folder contains evaluation outputs, predictions, and performance metrics.
